@echo off
setlocal
set "DEST=%LOCALAPPDATA%\ChatGPTScreenDrop"
set "STARTUP=%APPDATA%\Microsoft\Windows\Start Menu\Programs\Startup"

echo Arret de ChatGPT ScreenDrop...
powershell.exe -NoProfile -ExecutionPolicy Bypass -Command "$me=$PID; Get-CimInstance Win32_Process ^| Where-Object { $_.ProcessId -ne $me -and $_.Name -match '^powershell(\.exe)?$' -and $_.CommandLine -match 'ChatGPTScreenDrop\.ps1' } ^| ForEach-Object { Stop-Process -Id $_.ProcessId -Force -ErrorAction SilentlyContinue }" >nul 2>&1

del /Q "%STARTUP%\ChatGPT ScreenDrop.lnk" >nul 2>&1
cd /d "%TEMP%"
rmdir /S /Q "%DEST%" >nul 2>&1

echo Desinstallation terminee.
pause
