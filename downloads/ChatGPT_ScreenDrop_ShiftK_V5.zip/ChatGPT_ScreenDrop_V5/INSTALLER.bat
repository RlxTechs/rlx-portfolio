@echo off
setlocal EnableExtensions
chcp 65001 >nul
set "DEST=%LOCALAPPDATA%\ChatGPTScreenDrop"
set "STARTUP=%APPDATA%\Microsoft\Windows\Start Menu\Programs\Startup"

echo.
echo ================================================
echo   ChatGPT ScreenDrop V5 - Installation
echo ================================================
echo.

if not exist "%DEST%" mkdir "%DEST%"

rem Stop previous ScreenDrop copies, but never kill this installer helper PowerShell itself.
powershell.exe -NoProfile -ExecutionPolicy Bypass -Command "$me=$PID; Get-CimInstance Win32_Process ^| Where-Object { $_.ProcessId -ne $me -and $_.Name -match '^powershell(\.exe)?$' -and $_.CommandLine -match 'ChatGPTScreenDrop\.ps1' } ^| ForEach-Object { Stop-Process -Id $_.ProcessId -Force -ErrorAction SilentlyContinue }" >nul 2>&1

copy /Y "%~dp0ChatGPTScreenDrop.ps1" "%DEST%\ChatGPTScreenDrop.ps1" >nul
copy /Y "%~dp0UNINSTALLER.bat" "%DEST%\UNINSTALLER.bat" >nul
copy /Y "%~dp0DIAGNOSTIC.bat" "%DEST%\DIAGNOSTIC.bat" >nul

rem Remove the buggy V3 launcher if it exists.
del /Q "%DEST%\StartHidden.vbs" >nul 2>&1

rem Create a Startup shortcut DIRECTLY to PowerShell. No VBScript is used in V5.
powershell.exe -NoProfile -ExecutionPolicy Bypass -Command "$ws=New-Object -ComObject WScript.Shell; $lnk=$ws.CreateShortcut('%STARTUP%\ChatGPT ScreenDrop.lnk'); $lnk.TargetPath='%SystemRoot%\System32\WindowsPowerShell\v1.0\powershell.exe'; $lnk.Arguments='-NoProfile -ExecutionPolicy Bypass -STA -WindowStyle Hidden -File ""%LOCALAPPDATA%\ChatGPTScreenDrop\ChatGPTScreenDrop.ps1""'; $lnk.WorkingDirectory='%LOCALAPPDATA%\ChatGPTScreenDrop'; $lnk.IconLocation='%SystemRoot%\System32\shell32.dll,167'; $lnk.Save()"

rem Launch now, hidden.
start "" powershell.exe -NoProfile -ExecutionPolicy Bypass -STA -WindowStyle Hidden -File "%DEST%\ChatGPTScreenDrop.ps1"

echo.
echo Installation terminee.
echo.
echo IMPORTANT :
echo  1. Reviens une fois sur la conversation ChatGPT que tu veux utiliser.
echo  2. Ensuite tu peux aller sur le Bureau ou dans n'importe quelle app.
echo  3. SHIFT + K = capture de l'ecran actuel + collage dans ce ChatGPT.
echo.
echo V5 corrige le redimensionnement de Chrome : aucune division/snap forcee.
echo.
echo Appuie sur une touche pour fermer cette fenetre.
pause >nul
