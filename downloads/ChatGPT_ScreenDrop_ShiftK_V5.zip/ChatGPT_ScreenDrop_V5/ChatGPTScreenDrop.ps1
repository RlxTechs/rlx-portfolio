# ChatGPT ScreenDrop V5
# Global Shift+K -> capture monitor under mouse -> paste into current or most recently visited ChatGPT tab in Chrome.
# Windows PowerShell 5.1 compatible. No external dependencies.

$ErrorActionPreference = 'SilentlyContinue'
Add-Type -AssemblyName System.Windows.Forms
Add-Type -AssemblyName System.Drawing
Add-Type -AssemblyName UIAutomationClient
Add-Type -AssemblyName UIAutomationTypes

Add-Type @'
using System;
using System.Text;
using System.Runtime.InteropServices;
public static class SDNative {
    [DllImport("user32.dll")] public static extern IntPtr GetForegroundWindow();
    [DllImport("user32.dll")] public static extern bool SetForegroundWindow(IntPtr hWnd);
    [DllImport("user32.dll")] public static extern bool ShowWindowAsync(IntPtr hWnd, int nCmdShow);
    [DllImport("user32.dll")] public static extern bool IsIconic(IntPtr hWnd);
    [DllImport("user32.dll")] public static extern bool IsZoomed(IntPtr hWnd);
    [DllImport("user32.dll")] public static extern bool BringWindowToTop(IntPtr hWnd);
    [DllImport("user32.dll")] public static extern bool AttachThreadInput(uint idAttach, uint idAttachTo, bool fAttach);
    [DllImport("kernel32.dll")] public static extern uint GetCurrentThreadId();
    [DllImport("user32.dll")] public static extern bool IsWindow(IntPtr hWnd);
    [DllImport("user32.dll")] public static extern bool IsWindowVisible(IntPtr hWnd);
    [DllImport("user32.dll")] public static extern short GetAsyncKeyState(int vKey);
    [DllImport("user32.dll")] public static extern bool GetCursorPos(out POINT lpPoint);
    [DllImport("user32.dll")] public static extern bool SetCursorPos(int X, int Y);
    [DllImport("user32.dll")] public static extern void mouse_event(uint dwFlags, uint dx, uint dy, uint dwData, UIntPtr dwExtraInfo);
    [DllImport("user32.dll")] public static extern uint GetWindowThreadProcessId(IntPtr hWnd, out uint processId);
    [DllImport("user32.dll")] public static extern bool EnumWindows(EnumWindowsProc lpEnumFunc, IntPtr lParam);
    public delegate bool EnumWindowsProc(IntPtr hWnd, IntPtr lParam);
    [StructLayout(LayoutKind.Sequential)] public struct POINT { public int X; public int Y; }
}
'@

$BaseDir = Split-Path -Parent $MyInvocation.MyCommand.Path
$LogPath = Join-Path $BaseDir 'ScreenDrop.log'
function Write-Log([string]$Message) {
    try { Add-Content -LiteralPath $LogPath -Value ("{0:yyyy-MM-dd HH:mm:ss.fff}  {1}" -f (Get-Date), $Message) -Encoding UTF8 } catch {}
}

# One running copy only.
$createdNew = $false
$mutex = New-Object System.Threading.Mutex($true, 'Global\ChatGPTScreenDropV5', [ref]$createdNew)
if (-not $createdNew) { exit }

$script:Running = $true
$script:Paused = $false
$script:LastScan = [datetime]::MinValue
$script:LastChatHwnd = [IntPtr]::Zero
$script:LastChatTabElement = $null
$script:LastChatTabName = ''
$script:LastChatTabIndex = -1

function Get-ProcessNameFromHwnd([IntPtr]$Hwnd) {
    if ($Hwnd -eq [IntPtr]::Zero) { return '' }
    [uint32]$procId = 0
    [SDNative]::GetWindowThreadProcessId($Hwnd, [ref]$procId) | Out-Null
    if ($procId -eq 0) { return '' }
    try { return (Get-Process -Id $procId -ErrorAction Stop).ProcessName } catch { return '' }
}

function Get-Root([IntPtr]$Hwnd) {
    try { return [System.Windows.Automation.AutomationElement]::FromHandle($Hwnd) } catch { return $null }
}

function Get-ChromeAddress([IntPtr]$Hwnd) {
    $root = Get-Root $Hwnd
    if ($null -eq $root) { return $null }
    try {
        $edits = $root.FindAll(
            [System.Windows.Automation.TreeScope]::Descendants,
            (New-Object System.Windows.Automation.PropertyCondition(
                [System.Windows.Automation.AutomationElement]::ControlTypeProperty,
                [System.Windows.Automation.ControlType]::Edit
            ))
        )
        foreach ($el in $edits) {
            try {
                $valuePattern = $el.GetCurrentPattern([System.Windows.Automation.ValuePattern]::Pattern)
                if ($null -eq $valuePattern) { continue }
                $value = [string]$valuePattern.Current.Value
                if ($value -match '^https?://') { return $value }
                if ($value -match 'chatgpt\.com') { return $value }
            } catch {}
        }
    } catch {}
    return $null
}

function Test-ChatUrl([string]$Url) {
    if ([string]::IsNullOrWhiteSpace($Url)) { return $false }
    return ($Url -match '(^|://)(www\.)?chatgpt\.com(/|$)')
}

function Get-TabItems([IntPtr]$Hwnd) {
    $root = Get-Root $Hwnd
    if ($null -eq $root) { return @() }
    try {
        return @($root.FindAll(
            [System.Windows.Automation.TreeScope]::Descendants,
            (New-Object System.Windows.Automation.PropertyCondition(
                [System.Windows.Automation.AutomationElement]::ControlTypeProperty,
                [System.Windows.Automation.ControlType]::TabItem
            ))
        ))
    } catch { return @() }
}

function Get-SelectedTabInfo([IntPtr]$Hwnd) {
    $tabs = @(Get-TabItems $Hwnd)
    for ($i = 0; $i -lt $tabs.Count; $i++) {
        $el = $tabs[$i]
        try {
            $sp = $el.GetCurrentPattern([System.Windows.Automation.SelectionItemPattern]::Pattern)
            if ($null -ne $sp -and $sp.Current.IsSelected) {
                return [pscustomobject]@{ Element = $el; Name = [string]$el.Current.Name; Index = $i }
            }
        } catch {}
    }
    return $null
}

function Select-TabElement($Element) {
    if ($null -eq $Element) { return $false }
    try {
        $sp = $Element.GetCurrentPattern([System.Windows.Automation.SelectionItemPattern]::Pattern)
        if ($null -ne $sp) {
            $sp.Select()
            Start-Sleep -Milliseconds 160
            return $true
        }
    } catch {}
    try {
        $rect = $Element.Current.BoundingRectangle
        if ($rect.Width -gt 10 -and $rect.Height -gt 10) {
            $x = [int]($rect.Left + ($rect.Width / 2))
            $y = [int]($rect.Top + ($rect.Height / 2))
            [SDNative]::SetCursorPos($x, $y) | Out-Null
            [SDNative]::mouse_event(0x0002,0,0,0,[UIntPtr]::Zero)
            [SDNative]::mouse_event(0x0004,0,0,0,[UIntPtr]::Zero)
            Start-Sleep -Milliseconds 160
            return $true
        }
    } catch {}
    return $false
}

function Select-RememberedChatTab([IntPtr]$Hwnd) {
    # Best case: the exact UIA tab object is still alive.
    if ($null -ne $script:LastChatTabElement) {
        if (Select-TabElement $script:LastChatTabElement) {
            Start-Sleep -Milliseconds 120
            if (Test-ChatUrl (Get-ChromeAddress $Hwnd)) { return $true }
        }
    }

    # Re-find by previous tab index/name if Chrome rebuilt its accessibility tree.
    $tabs = @(Get-TabItems $Hwnd)
    if ($script:LastChatTabIndex -ge 0 -and $script:LastChatTabIndex -lt $tabs.Count) {
        $candidate = $tabs[$script:LastChatTabIndex]
        $name = ''
        try { $name = [string]$candidate.Current.Name } catch {}
        if ([string]::IsNullOrWhiteSpace($script:LastChatTabName) -or $name -eq $script:LastChatTabName) {
            if (Select-TabElement $candidate) {
                Start-Sleep -Milliseconds 120
                if (Test-ChatUrl (Get-ChromeAddress $Hwnd)) {
                    $script:LastChatTabElement = $candidate
                    return $true
                }
            }
        }
    }

    if (-not [string]::IsNullOrWhiteSpace($script:LastChatTabName)) {
        for ($i = 0; $i -lt $tabs.Count; $i++) {
            $candidate = $tabs[$i]
            $name = ''
            try { $name = [string]$candidate.Current.Name } catch {}
            if ($name -eq $script:LastChatTabName) {
                if (Select-TabElement $candidate) {
                    Start-Sleep -Milliseconds 120
                    if (Test-ChatUrl (Get-ChromeAddress $Hwnd)) {
                        $script:LastChatTabElement = $candidate
                        $script:LastChatTabIndex = $i
                        return $true
                    }
                }
            }
        }
    }
    return $false
}

function Remember-CurrentChatTab([IntPtr]$Hwnd) {
    if ((Get-ProcessNameFromHwnd $Hwnd) -ne 'chrome') { return }
    $url = Get-ChromeAddress $Hwnd
    if (-not (Test-ChatUrl $url)) { return }
    $selected = Get-SelectedTabInfo $Hwnd
    $script:LastChatHwnd = $Hwnd
    if ($null -ne $selected) {
        $script:LastChatTabElement = $selected.Element
        $script:LastChatTabName = $selected.Name
        $script:LastChatTabIndex = $selected.Index
    }
}

function Get-VisibleChromeWindows {
    $list = New-Object System.Collections.Generic.List[System.IntPtr]
    $callback = [SDNative+EnumWindowsProc]{
        param([IntPtr]$h, [IntPtr]$l)
        if ([SDNative]::IsWindowVisible($h) -and (Get-ProcessNameFromHwnd $h) -eq 'chrome') {
            $list.Add($h)
        }
        return $true
    }
    [SDNative]::EnumWindows($callback, [IntPtr]::Zero) | Out-Null
    return @($list)
}

function Save-CurrentTab([IntPtr]$Hwnd) {
    if ((Get-ProcessNameFromHwnd $Hwnd) -ne 'chrome') { return $null }
    return Get-SelectedTabInfo $Hwnd
}

function Find-ChatTarget([IntPtr]$OriginalHwnd) {
    # 1) Exact current ChatGPT tab wins, even if the message box itself is not focused.
    if ((Get-ProcessNameFromHwnd $OriginalHwnd) -eq 'chrome') {
        $url = Get-ChromeAddress $OriginalHwnd
        if (Test-ChatUrl $url) {
            Remember-CurrentChatTab $OriginalHwnd
            return [pscustomobject]@{ Hwnd = $OriginalHwnd; NeedsTabSelect = $false }
        }
    }

    # 2) Most recently visited ChatGPT tab, including a hidden tab in the same Chrome window.
    if ($script:LastChatHwnd -ne [IntPtr]::Zero -and [SDNative]::IsWindow($script:LastChatHwnd)) {
        return [pscustomobject]@{ Hwnd = $script:LastChatHwnd; NeedsTabSelect = $true }
    }

    # 3) Any Chrome window that already has ChatGPT as its currently active tab.
    foreach ($h in (Get-VisibleChromeWindows)) {
        if (Test-ChatUrl (Get-ChromeAddress $h)) {
            Remember-CurrentChatTab $h
            return [pscustomobject]@{ Hwnd = $h; NeedsTabSelect = $false }
        }
    }
    return $null
}

function Capture-MonitorUnderCursor {
    $p = New-Object SDNative+POINT
    [SDNative]::GetCursorPos([ref]$p) | Out-Null
    $screen = [System.Windows.Forms.Screen]::FromPoint((New-Object System.Drawing.Point($p.X, $p.Y)))
    $b = $screen.Bounds
    $bmp = New-Object System.Drawing.Bitmap($b.Width, $b.Height, [System.Drawing.Imaging.PixelFormat]::Format32bppArgb)
    $g = [System.Drawing.Graphics]::FromImage($bmp)
    try { $g.CopyFromScreen($b.Left, $b.Top, 0, 0, $b.Size, [System.Drawing.CopyPixelOperation]::SourceCopy) }
    finally { $g.Dispose() }
    return $bmp
}

function Focus-ChatComposer([IntPtr]$Hwnd) {
    $root = Get-Root $Hwnd
    if ($null -eq $root) { return $false }

    $types = @([System.Windows.Automation.ControlType]::Edit, [System.Windows.Automation.ControlType]::Document)
    $best = $null
    $bestScore = -999999.0
    $rootRect = $root.Current.BoundingRectangle

    foreach ($ct in $types) {
        try {
            $items = $root.FindAll(
                [System.Windows.Automation.TreeScope]::Descendants,
                (New-Object System.Windows.Automation.PropertyCondition(
                    [System.Windows.Automation.AutomationElement]::ControlTypeProperty,
                    $ct
                ))
            )
            foreach ($el in $items) {
                try {
                    if (-not $el.Current.IsEnabled) { continue }
                    $r = $el.Current.BoundingRectangle
                    if ($r.Width -lt 160 -or $r.Height -lt 24) { continue }
                    if ($r.Top -lt ($rootRect.Top + ($rootRect.Height * 0.48))) { continue }
                    $name = [string]$el.Current.Name
                    $value = ''
                    try {
                        $vp = $el.GetCurrentPattern([System.Windows.Automation.ValuePattern]::Pattern)
                        if ($null -ne $vp) { $value = [string]$vp.Current.Value }
                    } catch {}
                    if ($value -match '^https?://' -or $name -match '(address|adresse|omnibox|search the web|barre d.adresse)') { continue }

                    $bottomRatio = if ($rootRect.Height -gt 0) { ($r.Bottom - $rootRect.Top) / $rootRect.Height } else { 0 }
                    $score = ($bottomRatio * 1500.0) + [Math]::Min($r.Width, 1500)
                    if ($name -match '(message|ask|demandez|demander|chatgpt|prompt|question)') { $score += 2500 }
                    if ($r.Height -gt 300) { $score -= 1000 }
                    if ($score -gt $bestScore) { $bestScore = $score; $best = $el }
                } catch {}
            }
        } catch {}
    }

    if ($null -ne $best) {
        try { $best.SetFocus(); Start-Sleep -Milliseconds 120; return $true } catch {}
        try {
            $r = $best.Current.BoundingRectangle
            $x = [int]($r.Left + [Math]::Min([Math]::Max($r.Width * 0.25, 80), $r.Width - 30))
            $y = [int]($r.Top + ($r.Height / 2))
            [SDNative]::SetCursorPos($x, $y) | Out-Null
            [SDNative]::mouse_event(0x0002,0,0,0,[UIntPtr]::Zero)
            [SDNative]::mouse_event(0x0004,0,0,0,[UIntPtr]::Zero)
            Start-Sleep -Milliseconds 140
            return $true
        } catch {}
    }

    # Reliable visual fallback for the current ChatGPT layout: lower center of the page, above the bottom edge.
    try {
        $r = $root.Current.BoundingRectangle
        $x = [int]($r.Left + ($r.Width * 0.59))
        $y = [int]($r.Bottom - [Math]::Max(95, [Math]::Min(145, $r.Height * 0.12)))
        [SDNative]::SetCursorPos($x, $y) | Out-Null
        [SDNative]::mouse_event(0x0002,0,0,0,[UIntPtr]::Zero)
        [SDNative]::mouse_event(0x0004,0,0,0,[UIntPtr]::Zero)
        Start-Sleep -Milliseconds 160
        return $true
    } catch {}
    return $false
}

function Set-ClipboardImageSafe([System.Drawing.Bitmap]$Bmp) {
    for ($i = 0; $i -lt 10; $i++) {
        try {
            [System.Windows.Forms.Clipboard]::SetImage($Bmp)
            return $true
        } catch { Start-Sleep -Milliseconds 80 }
    }
    return $false
}

function Show-Toast([string]$Title, [string]$Text) {
    try {
        $script:Tray.BalloonTipTitle = $Title
        $script:Tray.BalloonTipText = $Text
        $script:Tray.ShowBalloonTip(2500)
    } catch {}
}

function Force-ForegroundNoResize([IntPtr]$Hwnd) {
    if ($Hwnd -eq [IntPtr]::Zero -or -not [SDNative]::IsWindow($Hwnd)) { return $false }
    try {
        $fg = [SDNative]::GetForegroundWindow()
        [uint32]$dummy = 0
        [uint32]$targetThread = [SDNative]::GetWindowThreadProcessId($Hwnd, [ref]$dummy)
        [uint32]$fgThread = 0
        if ($fg -ne [IntPtr]::Zero) {
            [uint32]$dummy2 = 0
            $fgThread = [SDNative]::GetWindowThreadProcessId($fg, [ref]$dummy2)
        }
        $currentThread = [SDNative]::GetCurrentThreadId()

        if ($fgThread -ne 0 -and $fgThread -ne $currentThread) { [SDNative]::AttachThreadInput($currentThread, $fgThread, $true) | Out-Null }
        if ($targetThread -ne 0 -and $targetThread -ne $currentThread) { [SDNative]::AttachThreadInput($currentThread, $targetThread, $true) | Out-Null }
        [SDNative]::BringWindowToTop($Hwnd) | Out-Null
        $ok = [SDNative]::SetForegroundWindow($Hwnd)
        if ($targetThread -ne 0 -and $targetThread -ne $currentThread) { [SDNative]::AttachThreadInput($currentThread, $targetThread, $false) | Out-Null }
        if ($fgThread -ne 0 -and $fgThread -ne $currentThread) { [SDNative]::AttachThreadInput($currentThread, $fgThread, $false) | Out-Null }
        return $ok
    } catch {
        try { return [SDNative]::SetForegroundWindow($Hwnd) } catch { return $false }
    }
}

function Activate-WindowNoResize([IntPtr]$Hwnd) {
    if ($Hwnd -eq [IntPtr]::Zero -or -not [SDNative]::IsWindow($Hwnd)) { return $false }

    # IMPORTANT V5: never call SW_RESTORE on a normal/maximized window.
    # SW_RESTORE on a maximized Chrome window was what made it jump back to its
    # old restored rectangle, which looked like Windows had split the screen in two.
    $wasMinimized = [SDNative]::IsIconic($Hwnd)
    if ($wasMinimized) {
        [SDNative]::ShowWindowAsync($Hwnd, 9) | Out-Null # SW_RESTORE only when actually minimized
        Start-Sleep -Milliseconds 140
    }

    Force-ForegroundNoResize $Hwnd | Out-Null
    Start-Sleep -Milliseconds 160
    return $wasMinimized
}

function Return-ToOriginalWindow([IntPtr]$OriginalHwnd, [IntPtr]$TargetHwnd, [bool]$TargetWasMinimized) {
    if ($OriginalHwnd -ne [IntPtr]::Zero -and $OriginalHwnd -ne $TargetHwnd -and [SDNative]::IsWindow($OriginalHwnd)) {
        Start-Sleep -Milliseconds 120
        Force-ForegroundNoResize $OriginalHwnd | Out-Null
        Start-Sleep -Milliseconds 100
    }

    # If Chrome had been minimized before Shift+K, put it back exactly that way
    # after the paste so ScreenDrop does not alter the user's desktop layout.
    if ($TargetWasMinimized -and $OriginalHwnd -ne $TargetHwnd -and [SDNative]::IsWindow($TargetHwnd)) {
        [SDNative]::ShowWindowAsync($TargetHwnd, 6) | Out-Null # SW_MINIMIZE
    }
}

function Send-ScreenshotToChatGpt {
    $targetWasMinimized = $false
    $originalHwnd = [SDNative]::GetForegroundWindow()
    $originalChromeTab = Save-CurrentTab $originalHwnd
    $mouse = New-Object SDNative+POINT
    [SDNative]::GetCursorPos([ref]$mouse) | Out-Null

    $bmp = Capture-MonitorUnderCursor
    if ($null -eq $bmp) { Write-Log 'Capture failed.'; return }

    try {
        $target = Find-ChatTarget $originalHwnd
        if ($null -eq $target) {
            [System.Media.SystemSounds]::Exclamation.Play()
            Show-Toast 'Aucun ChatGPT cible' 'Visite une conversation ChatGPT dans Chrome une premiere fois, puis refais Shift+K.'
            Write-Log 'No ChatGPT target found.'
            return
        }

        $targetHwnd = $target.Hwnd
        $targetWasMinimized = Activate-WindowNoResize $targetHwnd
        Start-Sleep -Milliseconds 80

        if ($target.NeedsTabSelect) {
            if (-not (Select-RememberedChatTab $targetHwnd)) {
                # Maybe it became current in the meantime.
                if (-not (Test-ChatUrl (Get-ChromeAddress $targetHwnd))) {
                    Show-Toast 'ChatGPT non retrouve' 'Reviens une fois sur la conversation ChatGPT voulue, puis Shift+K retiendra cet onglet.'
                    Write-Log 'Remembered ChatGPT tab could not be re-selected.'
                    return
                }
            }
        }

        Remember-CurrentChatTab $targetHwnd
        Focus-ChatComposer $targetHwnd | Out-Null

        if (-not (Set-ClipboardImageSafe $bmp)) {
            Show-Toast 'Presse-papiers occupe' 'La capture a echoue. Reessaie Shift+K.'
            Write-Log 'Clipboard image set failed.'
            return
        }

        Start-Sleep -Milliseconds 100
        [System.Windows.Forms.SendKeys]::SendWait('^v')
        Start-Sleep -Milliseconds 500
        [System.Media.SystemSounds]::Asterisk.Play()
        Write-Log 'Screenshot pasted into ChatGPT.'

        # Restore mouse location first.
        [SDNative]::SetCursorPos($mouse.X, $mouse.Y) | Out-Null

        # Restore the previous Chrome tab if Shift+K came from another tab in that same Chrome window.
        if ($null -ne $originalChromeTab -and $originalHwnd -eq $targetHwnd) {
            try {
                if ($originalChromeTab.Element -ne $script:LastChatTabElement) {
                    Select-TabElement $originalChromeTab.Element | Out-Null
                }
            } catch {}
        }

        # Restore exactly where the user was, without changing Chrome's size/state.
        Return-ToOriginalWindow $originalHwnd $targetHwnd $targetWasMinimized
    }
    catch {
        Write-Log ("Unhandled send error: " + $_.Exception.Message)
    }
    finally {
        $bmp.Dispose()
        [SDNative]::SetCursorPos($mouse.X, $mouse.Y) | Out-Null
        try {
            if ($null -ne $target -and $null -ne $target.Hwnd) {
                $th = [IntPtr]$target.Hwnd
                if ($originalHwnd -ne $th -and [SDNative]::GetForegroundWindow() -eq $th) {
                    Return-ToOriginalWindow $originalHwnd $th $targetWasMinimized
                }
            }
        } catch {}
    }
}

# Tray icon and controls.
$script:Tray = New-Object System.Windows.Forms.NotifyIcon
$script:Tray.Icon = [System.Drawing.SystemIcons]::Application
$script:Tray.Text = 'ChatGPT ScreenDrop V5 - Shift+K'
$script:Tray.Visible = $true
$menu = New-Object System.Windows.Forms.ContextMenuStrip
$pauseItem = $menu.Items.Add('Pause / Reprendre')
$logItem = $menu.Items.Add('Ouvrir le journal')
$exitItem = $menu.Items.Add('Quitter')
$pauseItem.Add_Click({
    $script:Paused = -not $script:Paused
    if ($script:Paused) { Show-Toast 'ScreenDrop en pause' 'Shift+K est desactive.' }
    else { Show-Toast 'ScreenDrop actif' 'Shift+K est actif.' }
})
$logItem.Add_Click({ try { Start-Process notepad.exe $LogPath } catch {} })
$exitItem.Add_Click({ $script:Running = $false })
$script:Tray.ContextMenuStrip = $menu

Write-Log 'ScreenDrop V5 started.'
Show-Toast 'ChatGPT ScreenDrop V5 actif' 'Shift+K capture et colle sans redimensionner Chrome.'

$VK_SHIFT = 0x10
$VK_K = 0x4B
$wasDown = $false

while ($script:Running) {
    [System.Windows.Forms.Application]::DoEvents()

    # Track the exact last ChatGPT tab whenever the user visits it.
    if (((Get-Date) - $script:LastScan).TotalMilliseconds -ge 350) {
        $script:LastScan = Get-Date
        $fg = [SDNative]::GetForegroundWindow()
        if ((Get-ProcessNameFromHwnd $fg) -eq 'chrome') {
            if (Test-ChatUrl (Get-ChromeAddress $fg)) { Remember-CurrentChatTab $fg }
        }
    }

    $shiftDown = (([SDNative]::GetAsyncKeyState($VK_SHIFT) -band 0x8000) -ne 0)
    $kDown = (([SDNative]::GetAsyncKeyState($VK_K) -band 0x8000) -ne 0)
    $down = ($shiftDown -and $kDown)

    if ($down -and -not $wasDown -and -not $script:Paused) {
        Send-ScreenshotToChatGpt
    }
    $wasDown = $down
    Start-Sleep -Milliseconds 20
}

Write-Log 'ScreenDrop V5 stopped.'
$script:Tray.Visible = $false
$script:Tray.Dispose()
try { $mutex.ReleaseMutex() } catch {}
$mutex.Dispose()
