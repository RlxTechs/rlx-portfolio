@echo off
set "DEST=%LOCALAPPDATA%\ChatGPTScreenDrop"
echo ================================================
echo ChatGPT ScreenDrop - Diagnostic
echo ================================================
echo.
echo Dossier : %DEST%
echo.
if exist "%DEST%\ScreenDrop.log" (
    echo Dernieres lignes du journal :
    echo.
    powershell.exe -NoProfile -Command "Get-Content -LiteralPath '%DEST%\ScreenDrop.log' -Tail 40"
) else (
    echo Aucun journal trouve. L'application n'a peut-etre pas demarre.
)
echo.
echo Processus ScreenDrop :
powershell.exe -NoProfile -Command "Get-CimInstance Win32_Process ^| Where-Object { $_.Name -match '^powershell(\.exe)?$' -and $_.CommandLine -match 'ChatGPTScreenDrop\.ps1' } ^| Select-Object ProcessId,CommandLine ^| Format-List"
echo.
pause
